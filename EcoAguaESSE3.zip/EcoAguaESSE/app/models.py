from django.contrib.auth.models import User, AbstractUser
from django.db import models
from django.conf import settings
from django.utils.translation import ugettext_lazy as _

class PessoaUsuario(models.Model):
    Fk_username = models.ForeignKey(User, verbose_name=("Cadastro"), on_delete=models.CASCADE, related_name="app_boleto", default=None)
    telefone = models.IntegerField(default=None)
    cpf = models.IntegerField(default=None)
    cep = models.IntegerField(default=None)
    endereco = models.CharField(max_length=250, default=None)
    pais = models.CharField(max_length=100, default=None) 
    estado = models.CharField(max_length=100, default=None)
    cidade = models.CharField(max_length=100, default=None)

    def __str__(self):
        return str(self.Fk_username)

class Boleto(models.Model):
    qt_pessoas_casa = models.IntegerField( blank=False)
    data_boleto = models.DateTimeField( blank=False)
    qt_agua_consumida = models.FloatField( blank=False)
    total_conta = models.FloatField(blank=False)
    FK_username = models.ForeignKey(PessoaUsuario, verbose_name=("Cadastro"), on_delete=models.CASCADE, related_name="app_boleto", default=None)

    def __str__(self):
        return str(self.FK_username)






