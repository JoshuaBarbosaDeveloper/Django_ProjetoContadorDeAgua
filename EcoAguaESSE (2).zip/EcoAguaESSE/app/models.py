from django.contrib.auth.models import User, AbstractUser
from django.db import models
from django.conf import settings
from django.utils.translation import ugettext_lazy as _

class PessoaUsuario(models.Model):
    telephone = models.PositiveIntegerField(_("Telefone"))
    addres = models.CharField(max_length=150)
    cep = models.CharField(max_length=8, blank=False)
    cpf = models.CharField(max_length=11, blank=False)

class Boleto(models.Model):
    qt_pessoas_casa = models.IntegerField( blank=False)
    data_boleto = models.DateTimeField( blank=False)
    qt_agua_consumida = models.FloatField( blank=False)
    total_conta = models.FloatField(blank=False)
    FK_pessoa_cadastro = models.ForeignKey(User, verbose_name=("Cadastro"), on_delete=models.CASCADE, related_name="app_boleto", default=None)

    def __str__(self):
        return self.FK_pessoa_cadastro.FK_pessoa.username






