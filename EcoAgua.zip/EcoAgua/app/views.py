from django.shortcuts import render, get_object_or_404
from .models import Pessoa, Cadastro, Boleto
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .forms import FormularioPessoa, FormularioBoleto
#from django.core.mail import send_mail

def lista_boletos(request):
    lista_boleto = ['Boleto 1', 'Boleto 2', 'Boleto 3', 'Boleto 4', 'Boleto 5']
    return render(request, 'app/tela1/listaboleto.html', {'lista_boleto': lista_boleto})

def detalhes_boletos(request):
    return render(request, 'app/tela1/detalhesboleto.html')

def home(request):
    return render(request, 'app/home.html')

def formulario_pessoa(request):
    sent = False

    if request.method == 'POST':
        form = FormularioPessoa(request.POST)

        if form.is_valid():
            form.save()
            #return render(request, 'app/home.html')
            sent= True

    else:
        form = FormularioPessoa()
    
    return render(request, 'forms/formulario.html', {'form':form, 'sent':sent}) 

def formulario_boleto(request):
    sent = False

    if request.method == 'POST':
        form = FormularioBoleto(request.POST)

        if form.is_valid():
            form.save()
            #return render(request, 'app/home.html')
            sent= True

    else:
        form = FormularioBoleto()
    
    return render(request, 'forms/formulario_boleto.html', {'form':form, 'sent':sent}) 