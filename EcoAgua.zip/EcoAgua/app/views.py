from django.shortcuts import render

def lista_boletos(request):
    lista_boleto = ['Boleto 1', 'Boleto 2', 'Boleto 3', 'Boleto 4', 'Boleto 5']
    return render(request, 'app/tela1/listaboleto.html', {'lista_boleto': lista_boleto})

def detalhes_boletos(request):
    return render(request, 'app/tela1/detalhesboleto.html')

