from django import forms
from django.forms import ModelForm
from .models import Pessoa, Boleto, Cadastro

class FormularioPessoa(ModelForm):
    class Meta:
        model= Pessoa
        fields = ['nome', 'email', 'telefone', 'endereco', 'cep', 'cpf']

class FormularioBoleto(ModelForm):
    class Meta:
        model= Boleto
        fields = ['qt_pessoas_casa', 'data_boleto', 'qt_agua_consumida', 'total_conta', 'FK_pessoa_cadastro']
        
#class FormularioComentarios(ModelForm):
#    class Meta:
#        model = Comentarios
#        fields = ['nome', 'email', 'mensagem']
