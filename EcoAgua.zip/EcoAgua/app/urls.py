from django.urls import path
from .import views

app_name = 'app'

urlpatterns=[
    path('home/', views.home, name='home'),
    path('listaboleto/', views.lista_boletos, name='lista_boletos'),
    path('detalhesboleto/', views.detalhes_boletos, name='detalhe_boletos'),
    path('formulario/', views.formulario_pessoa, name='formularios'),
    path('formulario_boleto/', views.formulario_boleto, name='formularioboleto'),
]