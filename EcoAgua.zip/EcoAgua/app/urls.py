from django.urls import path
from .import views

app_name = 'app'

urlpatterns=[
    path('listaboleto/', views.lista_boletos, name='lista_boletos'),
    path('detalhesboleto/', views.detalhes_boletos, name='detalhe_boletos'),
]