from django.db import models

class Pessoa(models.Model):
    nome = models.CharField(max_length=200, db_index=True, blank=False)
    email = models.EmailField(max_length=100, default=None, blank=False)
    telefone = models.CharField(max_length=11, blank=False)
    endereco = models.CharField(max_length=254, blank=False)
    cep = models.CharField(max_length=8, blank=False)
    cpf = models.CharField(max_length=11, blank=False)

    def __str__(self):
        return self.nome

class Cadastro(models.Model):
    login = models.CharField(max_length=200, db_index=True, blank=False)
    senha = models.CharField(max_length=200, db_index=True, blank=False)
    FK_pessoa = models.OneToOneField(Pessoa, verbose_name=("Usuário"), on_delete=models.CASCADE, related_name="app_pessoa", default=None)

    def __str__(self):
        return self.FK_pessoa.nome

class Boleto(models.Model):
    qt_pessoas_casa = models.IntegerField( blank=False)
    data_boleto = models.DateTimeField( blank=False)
    qt_agua_consumida = models.FloatField( blank=False)
    total_conta = models.FloatField(blank=False)
    FK_pessoa_cadastro = models.ForeignKey(Cadastro, verbose_name=("Cadastro"), on_delete=models.CASCADE, related_name="app_boleto", default=None)

    def __str__(self):
        return self.FK_pessoa_cadastro, self.data_boleto






