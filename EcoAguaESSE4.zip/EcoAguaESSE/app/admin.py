from django.contrib import admin
from .models import *

@admin.register(Boleto)
class BoletoAdmin(admin.ModelAdmin):
    list_display = ('qt_pessoas_casa', 'data_emicao_boleto', 'qt_agua_consumida', 'total_conta', 'FK_username', 'status')
    ordering = ('status', 'data_emicao_boleto')


@admin.register(PessoaUsuario)
class PessoaUsuarioAdmin(admin.ModelAdmin):
    pass

