from django.shortcuts import render, get_object_or_404
from .models import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .forms import FormularioBoleto, FormularioPessoaUsuario
from django.http import HttpResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib.auth import authenticate, login
from .forms import FormularioLogin, FormularioRegistroUsuario
from django.contrib.auth.decorators import login_required

#from django.core.mail import send_mail

def lista_boletos(request):
    lista_boleto = ['Boleto 1', 'Boleto 2', 'Boleto 3', 'Boleto 4', 'Boleto 5']
    return render(request, 'app/tela1/listaboleto.html', {'lista_boleto': lista_boleto})

def detalhes_boletos(request):
    return render(request, 'app/tela1/detalhesboleto.html')

def home(request):
    return render(request, 'app/home.html')

def boletos_cadastrados(request):
    lista_objetos = Boleto.objects.all()
    
    return render(request, 'app/boletos_cadastrados.html', {'lista_objetos': lista_objetos})

def contato(request):
    return render(request, 'app/contato.html')

def economizar(request):
    return render(request, 'app/economizar.html')


def formulario(request):
    sent = False

    if request.method == 'POST':
        form = FormularioPessoaUsuario(request.POST)

        if form.is_valid():
            form.save()
            #return render(request, 'app/home.html')
            sent= True

    else:
        form = FormularioPessoaUsuario()
    
    return render(request, 'forms/formulario.html', {'form':form, 'sent':sent}) 

def formulario_boleto(request):
    sent = False

    if request.method == 'POST':
        form = FormularioBoleto(request.POST)

        if form.is_valid():
            form.save()
            #return render(request, 'app/home.html')
            sent= True

    else:
        form = FormularioBoleto()
    
    return render(request, 'forms/formulario_boleto.html', {'form':form, 'sent':sent}) 

@login_required
def painel_controle(request):
    return render(request, 'conta/painel_controle.html', {'section':'painel de controle'})

def registrar(request):
    if request.method == 'POST':
        formulario_usuario = FormularioRegistroUsuario(request.POST)
        if formulario_usuario.is_valid():
            novo_usuario = formulario_usuario.save(commit=False)
            novo_usuario.set_password(formulario_usuario.cleaned_data['senha'])
            novo_usuario.save()
            return render(request, 'conta/registro_realizado.html', {'formulario_usuario':formulario_usuario})
    else:
        formulario_usuario = FormularioRegistroUsuario()
    return render(request, 'conta/registrar.html', {'formulario_usuario':formulario_usuario})