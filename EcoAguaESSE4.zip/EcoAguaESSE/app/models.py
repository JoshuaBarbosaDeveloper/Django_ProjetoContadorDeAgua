from django.contrib.auth.models import User, AbstractUser
from django.db import models
from django.utils import timezone
from django.conf import settings
from django.utils.translation import ugettext_lazy as _

class PessoaUsuario(models.Model):
    Fk_username = models.ForeignKey(User, verbose_name=("Cadastro"), on_delete=models.CASCADE, related_name="app_boleto", default=None)
    telefone = models.IntegerField(default=None)
    cpf = models.IntegerField(default=None)
    cep = models.IntegerField(default=None)
    endereco = models.CharField(max_length=250, default=None)
    pais = models.CharField(max_length=100, default=None) 
    estado = models.CharField(max_length=100, default=None)
    cidade = models.CharField(max_length=100, default=None)

    def __str__(self):
        return str(self.Fk_username)

class GerenciarBoleto(models.Manager):
    def get_queryset(self):
        return super (GerenciarBoleto,self).get_queryset().filter(status='Cadastrado')

class Boleto(models.Model):
    STATUS_CHOICE = (('em branco', 'Em branco'), ('cadastrado', 'Cadastrado'))

    qt_pessoas_casa = models.IntegerField( blank=False)
    data_emicao_boleto = models.DateTimeField( blank=False)
    qt_agua_consumida = models.FloatField( blank=False)
    total_conta = models.FloatField(blank=False)
    FK_username = models.ForeignKey(PessoaUsuario, verbose_name=("Cadastro"), on_delete=models.CASCADE, related_name="app_boleto", default=None)
    status = models.CharField(max_length=10, choices=STATUS_CHOICE, default='cadastrado')
    data_cadastrado = models.DateTimeField(default=timezone.now)
    data_criacao = models.DateTimeField(auto_now_add=True)
    data_atualizacao = models.DateTimeField(auto_now_add=True)

    objects = models.Manager() 
    publicado = GerenciarBoleto()

    class Meta:
        ordering = ('data_emicao_boleto', )

    def __str__(self):
        return str(self.FK_username)







